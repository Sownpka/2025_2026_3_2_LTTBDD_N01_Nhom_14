import 'package:flutter/material.dart';
import '../../models/playlist.dart';
import '../../models/song.dart';
import '../../services/data_service.dart';
import '../../services/audio_service.dart';
import '../../services/setting_service.dart';
import '../player/player_screen.dart';
import '../../widgets/mini_player.dart';
import 'dart:async';

// StatefulWidget: giữ trạng thái bài hát đang chọn + lắng nghe dataService.
class PlaylistDetailScreen extends StatefulWidget {
  final Playlist playlist;
  final DataService dataService;
  const PlaylistDetailScreen({
    super.key,
    required this.playlist,
    required this.dataService,
  });

  @override
  State<PlaylistDetailScreen> createState() => _PlaylistDetailScreenState();
}

class _PlaylistDetailScreenState extends State<PlaylistDetailScreen> {
  StreamSubscription? _theoDoiMayPhat;

  @override
  void initState() {
    super.initState();
    widget.dataService.addListener(_refresh);
    caiDat.addListener(_refresh);
    _theoDoiMayPhat = mayPhat.playerStateStream.listen((trangThai) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    widget.dataService.removeListener(_refresh);
    caiDat.removeListener(_refresh);
    _theoDoiMayPhat?.cancel();
    super.dispose();
  }

  void _refresh() => mounted ? setState(() {}) : null;

  Route<void> _duongDanPlayer() {
    return PageRouteBuilder(
      transitionDuration: Duration.zero,
      reverseTransitionDuration: Duration.zero,
      pageBuilder: (context, animation, secondaryAnimation) =>
          PlayerScreen(dataService: widget.dataService),
    );
  }

  // Phat bai duoc chon, danh sach phat la toan bo bai trong playlist nay.
  void _chonBai(Song s) async {
    Navigator.push(context, _duongDanPlayer());
    if (baiDangPhat?.id != s.id) {
      await phatBai(s, _playlist.songs);
    }
  }

  Playlist get _playlist => widget.dataService.playlists.firstWhere(
    (e) => e.id == widget.playlist.id,
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(_playlist.name),
      actions: [IconButton(onPressed: _addSong, icon: const Icon(Icons.add))],
    ),
    body: _playlist.songs.isEmpty
        ? Center(child: Text(tr("Chưa có bài hát", "No songs")))
        : ListView.builder(
            itemCount: _playlist.songs.length,
            itemBuilder: (_, i) {
              final s = _playlist.songs[i];
              return SongItem(
                song: s,
                isSelected: s.id == baiDangPhat?.id,
                onTap: () => _chonBai(s),
                onDelete: () => _remove(s),
              );
            },
          ),
    bottomNavigationBar: MiniPlayer(dataService: widget.dataService),
  );

  void _remove(Song s) {
    widget.dataService.removeSongFromPlaylist(_playlist.id, s.id);
  }

  Future<void> _addSong() async {
    final ids = <String>[];
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialog) => AlertDialog(
          title: Text(tr("Thêm bài hát", "Add songs")),
          content: SizedBox(
            width: double.maxFinite,
            height: 350,
            child: ListView(
              children: widget.dataService.songs
                  .map(
                    (s) => CheckboxListTile(
                      value: ids.contains(s.id),
                      title: Text(s.title),
                      subtitle: Text(s.artist.name),
                      onChanged: (v) => setDialog(
                        () => v! ? ids.add(s.id) : ids.remove(s.id),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(tr("Huỷ", "Cancel")),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text('${tr("Thêm", "Add")} (${ids.length})'),
            ),
          ],
        ),
      ),
    );
    if (ok == true) {
      for (final id in ids) {
        widget.dataService.addSongToPlaylist(
          _playlist.id,
          widget.dataService.songs.firstWhere((e) => e.id == id),
        );
      }
    }
  }
}

// StatelessWidget: 1 dòng bài hát trong playlist.
class SongItem extends StatelessWidget {
  final Song song;
  final bool isSelected;
  final VoidCallback onTap, onDelete;

  const SongItem({
    super.key,
    required this.song,
    required this.onTap,
    required this.onDelete,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) => ListTile(
    onTap: onTap,
    selected: isSelected,
    leading: Icon(isSelected ? Icons.check_circle : Icons.music_note),
    title: Text(song.title),
    subtitle: Text(song.artist.name),
    trailing: IconButton(
      icon: const Icon(Icons.delete, color: Colors.red),
      onPressed: onDelete,
    ),
  );
}
